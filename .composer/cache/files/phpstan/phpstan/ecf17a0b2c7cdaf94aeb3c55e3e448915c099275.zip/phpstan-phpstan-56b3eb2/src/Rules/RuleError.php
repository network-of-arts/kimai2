<?php declare(strict_types = 1);

namespace PHPStan\Rules;

interface RuleError
{

	public function getMessage(): string;

}
