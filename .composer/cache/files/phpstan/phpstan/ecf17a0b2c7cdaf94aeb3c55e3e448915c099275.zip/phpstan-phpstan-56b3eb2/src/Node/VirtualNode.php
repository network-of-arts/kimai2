<?php declare(strict_types = 1);

namespace PHPStan\Node;

use PhpParser\Node;

interface VirtualNode extends Node
{

}
